export default () => /*html*/`
    <div>Offline pages</div>
`;